# -*- coding: utf-8 -*-

from .market_segment import MarketSegment  # NOQA
from .act import (AbstractAct, Act, ActType, ActObjective,
        AbstractActObjectivePattern, ActObjectivePattern, ActObjectivePatternComponent)  # NOQA
from .commercial_approach import CommercialApproach  # NOQA
from .strategy import *  # NOQA
