default_app_config = 'creme.assistants.apps.AssistantsConfig'
